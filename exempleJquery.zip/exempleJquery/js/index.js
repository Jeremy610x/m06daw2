// // $("p").hide(); //dirigirme a tos els tag p
// $("#idh3").hide();//dirigirme al id 
// $(".error").hide();//dirigirme a las classes errors
//quan el document carregui...
// $(document).ready(function(){
//         alert("Hola Jquery!!!")
// });
// $(function(){
//  if(confirm("Estas segur que vols continuar?")){
//  $("p").hide();
// }
// })

// $("#button1").click(()=>{

//     // $("p,h3").hide();
//     // $(this).hide();
// $("p.error").hide();


// console.log($("#intro").val())
// //escriure texte dins del paragraf idp2

// console.log($("#idp2").html("Hola hola daw2"))
$("#exA").click(()=>{



})


// })